/* =========================================================
   PHARMACARE JAVASCRIPT
   ========================================================= */


/* ================= IMAGE SLIDESHOW ================= */

const heroImages = [
    "images/Apharcy1.jpg",
    "images/Apharcy2.jpg"
];

let currentImage = 0;

const heroImage = document.getElementById("heroImage");

const dots = document.querySelectorAll(".dot");


function showImage(index) {

    currentImage = index;

    heroImage.style.opacity = "0";


    setTimeout(function () {

        heroImage.src = heroImages[currentImage];

        heroImage.style.opacity = "1";


        dots.forEach(function(dot, i) {

            dot.classList.remove("active");

            if (i === currentImage) {
                dot.classList.add("active");
            }

        });

    }, 250);
}


function nextImage() {

    currentImage++;

    if (currentImage >= heroImages.length) {
        currentImage = 0;
    }

    showImage(currentImage);
}


function previousImage() {

    currentImage--;

    if (currentImage < 0) {
        currentImage = heroImages.length - 1;
    }

    showImage(currentImage);
}


/* Automatically rotate every 5 seconds */

setInterval(function () {

    nextImage();

}, 5000);



/* ================= SCROLL ================= */

function scrollToSection(id) {

    const section = document.getElementById(id);

    if (section) {

        section.scrollIntoView({
            behavior: "smooth"
        });

    }

}



/* ================= MEDICINE DATABASE ================= */

/*
    These are DEMONSTRATION records only.

    Real medicine information should be verified
    from authoritative medicine sources before the
    system is used for real patients.
*/

const medicines = [

    {
        name: "Paracetamol",

        category: "Pain Relief",

        ingredients:
            "Active ingredient information should be verified from the specific product label.",

        uses:
            "General information about pain and fever relief.",

        directions:
            "Follow the product label or advice from a qualified healthcare professional.",

        warning:
            "Do not exceed the labelled dose. Taking too much paracetamol can cause serious liver injury."
    },


    {
        name: "Flu Relief",

        category: "Flu",

        ingredients:
            "Ingredients vary between products. Check the specific product packaging.",

        uses:
            "General cold and flu symptom information.",

        directions:
            "Follow the instructions on the specific product label.",

        warning:
            "Avoid combining medicines containing the same active ingredient."
    },


    {
        name: "Skin Care Cream",

        category: "Skin Care",

        ingredients:
            "Ingredients depend on the specific cream or product.",

        uses:
            "General skin-care information.",

        directions:
            "Use according to the specific product instructions.",

        warning:
            "Stop use and seek professional advice if irritation or an allergic reaction occurs."
    }

];



/* ================= MEDICINE SEARCH ================= */

const medicineSearch =
    document.getElementById("medicineSearch");

const suggestionBox =
    document.getElementById("searchSuggestions");


if (medicineSearch) {

    medicineSearch.addEventListener(
        "input",
        function () {

            const value =
                medicineSearch.value
                    .trim()
                    .toLowerCase();


            suggestionBox.innerHTML = "";


            if (value === "") {
                return;
            }


            const matches =
                medicines.filter(function (medicine) {

                    return medicine.name
                        .toLowerCase()
                        .includes(value);

                });


            matches.forEach(function (medicine) {

                const div =
                    document.createElement("div");

                div.className = "suggestion";

                div.textContent =
                    medicine.name;

                div.onclick = function () {

                    medicineSearch.value =
                        medicine.name;

                    suggestionBox.innerHTML = "";

                    showMedicine(medicine.name);

                };

                suggestionBox.appendChild(div);

            });


            /* Spelling correction */

            if (matches.length === 0) {

                const closest =
                    findClosestMedicine(value);


                if (closest) {

                    const div =
                        document.createElement("div");

                    div.className = "suggestion";

                    div.innerHTML =
                        `Did you mean:
                        <strong>${closest.name}</strong>?`;

                    div.onclick = function () {

                        medicineSearch.value =
                            closest.name;

                        suggestionBox.innerHTML = "";

                        showMedicine(closest.name);

                    };

                    suggestionBox.appendChild(div);

                }

            }

        }

    );

}



/* ================= SEARCH BUTTON ================= */

function searchMedicine() {

    const value =
        medicineSearch.value.trim();


    if (value === "") {

        alert("Please enter a medicine name.");

        return;

    }


    const medicine =
        medicines.find(function (item) {

            return item.name.toLowerCase() ===
                value.toLowerCase();

        });


    if (medicine) {

        showMedicine(medicine.name);

        suggestionBox.innerHTML = "";

        return;

    }


    const closest =
        findClosestMedicine(value);


    if (closest) {

        showMedicine(closest.name);

        medicineSearch.value =
            closest.name;

        suggestionBox.innerHTML = "";

    }

    else {

        document.getElementById(
            "medicineResult"
        ).innerHTML = `

            <div class="medicine-information">

                <h3>Medicine not found</h3>

                <p>
                    We could not find this medicine in
                    the current demonstration database.
                </p>

                <div class="safety-warning">
                    Please check the spelling or ask a
                    pharmacist for assistance.
                </div>

            </div>

        `;

    }

}



/* ================= DISPLAY MEDICINE ================= */

function showMedicine(name) {

    const medicine =
        medicines.find(function (item) {

            return item.name === name;

        });


    if (!medicine) {
        return;
    }


    document.getElementById(
        "medicineResult"
    ).innerHTML = `

        <div class="medicine-information">

            <h3>💊 ${medicine.name}</h3>

            <div class="info-row">

                <strong>Category:</strong>
                ${medicine.category}

            </div>


            <div class="info-row">

                <strong>Ingredients:</strong>
                ${medicine.ingredients}

            </div>


            <div class="info-row">

                <strong>General use:</strong>
                ${medicine.uses}

            </div>


            <div class="info-row">

                <strong>How to use:</strong>
                ${medicine.directions}

            </div>


            <div class="safety-warning">

                ⚠️ <strong>Safety:</strong>
                ${medicine.warning}

            </div>

        </div>

    `;

}



/* ================= SPELLING CORRECTION ================= */

function findClosestMedicine(word) {

    let closest = null;

    let smallestDistance = Infinity;


    medicines.forEach(function (medicine) {

        const distance =
            levenshtein(
                word.toLowerCase(),
                medicine.name.toLowerCase()
            );


        if (distance < smallestDistance) {

            smallestDistance = distance;

            closest = medicine;

        }

    });


    /*
       Only suggest a correction when the spelling
       is reasonably close.
    */

    if (smallestDistance <= 5) {

        return closest;

    }


    return null;

}



/* ================= LEVENSHTEIN DISTANCE ================= */

function levenshtein(a, b) {

    const matrix = [];


    for (let i = 0; i <= b.length; i++) {

        matrix[i] = [i];

    }


    for (let j = 0; j <= a.length; j++) {

        matrix[0][j] = j;

    }


    for (let i = 1; i <= b.length; i++) {

        for (let j = 1; j <= a.length; j++) {

            if (b.charAt(i - 1) ===
                a.charAt(j - 1)) {

                matrix[i][j] =
                    matrix[i - 1][j - 1];

            }

            else {

                matrix[i][j] =
                    Math.min(

                        matrix[i - 1][j - 1] + 1,

                        matrix[i][j - 1] + 1,

                        matrix[i - 1][j] + 1

                    );

            }

        }

    }


    return matrix[b.length][a.length];

}



/* ================= HEALTH CATEGORY ================= */

function selectHealth(category) {

    const select =
        document.getElementById("healthSelect");


    if (select) {

        select.value = category;

    }


    scrollToSection("symptoms");

}



/* ================= SYMPTOM ASSISTANT ================= */

function checkSymptoms() {

    const symptoms =
        document.getElementById(
            "symptomText"
        ).value.trim();


    const category =
        document.getElementById(
            "healthSelect"
        ).value;


    const result =
        document.getElementById(
            "symptomResult"
        );


    if (symptoms === "") {

        result.innerHTML = `

            <div class="safety-warning">

                Please describe your symptoms first.

            </div>

        `;

        return;

    }


    if (category === "") {

        result.innerHTML = `

            <div class="safety-warning">

                Please select a health area.

            </div>

        `;

        return;

    }


    let message = "";


    if (category === "Flu") {

        message =
            "You selected Flu. The system can provide general information about cold and flu medicines. A pharmacist or healthcare professional can help determine what is appropriate for you.";

    }


    else if (category === "Headache") {

        message =
            "You selected Headache. The system can provide general information about pain-relief medicines and their safety information.";

    }


    else if (category === "Stomach Ache") {

        message =
            "You selected Stomach Ache. Different causes can require different treatment. Consider discussing persistent or severe symptoms with a healthcare professional.";

    }


    else if (category === "Skin Problems") {

        message =
            "You selected Skin Problems. You can also use the Skin Assistant below for general skin-care information.";

    }


    result.innerHTML = `

        <div class="medicine-information">

            <h3>
                🩺 General Information
            </h3>

            <p>
                ${message}
            </p>

            <div class="safety-warning">

                ⚠️ This is not a diagnosis or prescription.
                Seek professional medical advice when necessary.

            </div>

        </div>

    `;

}



/* ================= SKIN IMAGE ================= */

const skinInput =
    document.getElementById("skinImage");


const preview =
    document.getElementById("imagePreview");


if (skinInput) {

    skinInput.addEventListener(
        "change",
        function () {

            const file =
                skinInput.files[0];


            if (!file) {
                return;
            }


            if (!file.type.startsWith("image/")) {

                alert("Please select an image file.");

                skinInput.value = "";

                return;

            }


            const reader =
                new FileReader();


            reader.onload = function (event) {

                preview.innerHTML = `

                    <img
                        src="${event.target.result}"
                        alt="Skin image preview">

                `;

            };


            reader.readAsDataURL(file);

        }

    );

}



/* ================= SKIN ANALYSIS ================= */

function analyzeSkin() {

    const file =
        skinInput.files[0];


    const result =
        document.getElementById(
            "skinResult"
        );


    if (!file) {

        result.innerHTML = `

            <div class="safety-warning">

                Please upload an image first.

            </div>

        `;

        return;

    }


    result.innerHTML = `

        <div class="medicine-information">

            <h3>
                📷 General Skin Information
            </h3>

            <p>
                The image has been uploaded successfully.
                A future backend/AI component can be
                connected here to provide carefully
                validated general information.
            </p>

            <div class="safety-warning">

                ⚠️ An image alone should not be used
                to diagnose a skin condition or determine
                prescription treatment.

            </div>

        </div>

    `;

}



/* ================= REMOVE SKIN IMAGE ================= */

function removeSkinImage() {

    skinInput.value = "";


    preview.innerHTML = `

        <span>🖼️</span>

        <p>
            Image preview will appear here
        </p>

    `;


    document.getElementById(
        "skinResult"
    ).innerHTML = "";

}



/* ================= COMMENTS ================= */

function submitComment() {

    const name =
        document.getElementById(
            "customerName"
        ).value.trim();


    const comment =
        document.getElementById(
            "customerComment"
        ).value.trim();


    if (name === "" || comment === "") {

        alert(
            "Please enter your name and comment."
        );

        return;

    }


    const commentsList =
        document.getElementById(
            "commentsList"
        );


    const firstLetter =
        name.charAt(0).toUpperCase();


    const newComment =
        document.createElement("div");


    newComment.className = "comment";


    newComment.innerHTML = `

        <div class="comment-avatar">
            ${firstLetter}
        </div>

        <div>

            <strong>
                ${escapeHTML(name)}
            </strong>

            <p>
                ${escapeHTML(comment)}
            </p>

        </div>

    `;


    commentsList.prepend(newComment);


    document.getElementById(
        "customerName"
    ).value = "";


    document.getElementById(
        "customerComment"
    ).value = "";

}



/* ================= SECURITY HELPER ================= */

function escapeHTML(text) {

    const div =
        document.createElement("div");

    div.textContent = text;

    return div.innerHTML;

}



/* ================= MOBILE SIDEBAR ================= */

const mobileMenu =
    document.querySelector(".mobile-menu");


const sidebar =
    document.querySelector(".sidebar");


if (mobileMenu) {

    mobileMenu.addEventListener(
        "click",
        function () {

            sidebar.classList.toggle("open");

        }
    );

}



/* ================= TOP SEARCH ================= */

const topSearch =
    document.getElementById("topSearch");


if (topSearch) {

    topSearch.addEventListener(
        "keydown",
        function (event) {

            if (event.key === "Enter") {

                const value =
                    topSearch.value.trim();


                if (value !== "") {

                    document.getElementById(
                        "medicineSearch"
                    ).value = value;


                    scrollToSection(
                        "medicines"
                    );


                    searchMedicine();

                }

            }

        }
    );

}